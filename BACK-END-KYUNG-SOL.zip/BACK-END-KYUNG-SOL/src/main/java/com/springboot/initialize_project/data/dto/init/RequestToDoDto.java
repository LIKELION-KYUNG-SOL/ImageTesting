package com.springboot.initialize_project.data.dto.init;

import lombok.Data;

@Data
public class RequestToDoDto {
    String name;
    String description;
}
