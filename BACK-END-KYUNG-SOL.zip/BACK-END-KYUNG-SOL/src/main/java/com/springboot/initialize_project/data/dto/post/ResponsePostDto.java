package com.springboot.initialize_project.data.dto.post;

import lombok.Data;

@Data
public class ResponsePostDto {
    private Long pid;
    private String subject;
}