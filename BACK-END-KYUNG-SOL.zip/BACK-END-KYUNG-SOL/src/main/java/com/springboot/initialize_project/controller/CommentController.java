package com.springboot.initialize_project.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/comment")
public class CommentController {

    //private final CommentService commentService;

    /*@Autowired
    public CommentService xlzl*/

}
