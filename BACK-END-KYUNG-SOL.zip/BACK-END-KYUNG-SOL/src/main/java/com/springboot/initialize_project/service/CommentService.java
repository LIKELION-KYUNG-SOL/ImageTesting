package com.springboot.initialize_project.service;

/*public interface CommentService {
    void createComment(String content,
                       HttpServletRequest servletRequest,
                       HttpServletResponse servletResponse);
}*/
