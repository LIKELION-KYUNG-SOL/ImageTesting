package com.springboot.initialize_project.data.dto.kakao;

import lombok.Data;

@Data
public class ResponseKakaoDto {
    String token;
    Boolean is_in;
}
