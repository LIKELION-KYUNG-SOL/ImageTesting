package com.springboot.initialize_project.data.dto.lecture;

import lombok.Data;

@Data
public class RequestLectureInfoDto {
    private Long postId;
}
