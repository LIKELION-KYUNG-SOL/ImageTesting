package com.springboot.initialize_project.service;

public interface MaskingService {
    String phoneMasking(String phoneNo);
    String crnMasking(String crn);
}
