package com.springboot.initialize_project.data.dto.sign;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class VerifyResponseDto {
    private boolean verify;
}
