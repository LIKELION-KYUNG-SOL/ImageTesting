package com.springboot.initialize_project.data.dto.kakao;

import lombok.Data;

@Data
public class RequestKakaoDto {
    String kakaoAccount;
}
