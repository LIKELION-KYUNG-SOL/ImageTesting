package com.springboot.initialize_project.data.dto.mail;

import lombok.Data;

@Data
public class ResponseVerificationMailDto {
    Integer verificationNumber;
}
